﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.GuardaCalcularToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LimpiarGridToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LimpiarVectoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton_doble = New System.Windows.Forms.RadioButton()
        Me.RadioButton_individual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_sofa = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton_cuerina = New System.Windows.Forms.RadioButton()
        Me.RadioButton_cuero = New System.Windows.Forms.RadioButton()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.column_venta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.column_tipo_sillon = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.column_tipo_tela = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.column_precio_costo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.column_precio_venta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox_numero_venta = New System.Windows.Forms.TextBox()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GuardaCalcularToolStripMenuItem, Me.LimpiarGridToolStripMenuItem, Me.LimpiarVectoresToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(571, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'GuardaCalcularToolStripMenuItem
        '
        Me.GuardaCalcularToolStripMenuItem.Name = "GuardaCalcularToolStripMenuItem"
        Me.GuardaCalcularToolStripMenuItem.Size = New System.Drawing.Size(116, 20)
        Me.GuardaCalcularToolStripMenuItem.Text = "Calcular y Guardar"
        '
        'LimpiarGridToolStripMenuItem
        '
        Me.LimpiarGridToolStripMenuItem.Name = "LimpiarGridToolStripMenuItem"
        Me.LimpiarGridToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.LimpiarGridToolStripMenuItem.Text = "Limpiar Grid"
        '
        'LimpiarVectoresToolStripMenuItem
        '
        Me.LimpiarVectoresToolStripMenuItem.Name = "LimpiarVectoresToolStripMenuItem"
        Me.LimpiarVectoresToolStripMenuItem.Size = New System.Drawing.Size(106, 20)
        Me.LimpiarVectoresToolStripMenuItem.Text = "Limpiar Vectores"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton_doble)
        Me.GroupBox1.Controls.Add(Me.RadioButton_individual)
        Me.GroupBox1.Controls.Add(Me.RadioButton_sofa)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(139, 104)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tipo de Sillón"
        '
        'RadioButton_doble
        '
        Me.RadioButton_doble.AutoSize = True
        Me.RadioButton_doble.Location = New System.Drawing.Point(17, 74)
        Me.RadioButton_doble.Name = "RadioButton_doble"
        Me.RadioButton_doble.Size = New System.Drawing.Size(53, 17)
        Me.RadioButton_doble.TabIndex = 4
        Me.RadioButton_doble.Text = "Doble"
        Me.RadioButton_doble.UseVisualStyleBackColor = True
        '
        'RadioButton_individual
        '
        Me.RadioButton_individual.AutoSize = True
        Me.RadioButton_individual.Location = New System.Drawing.Point(17, 51)
        Me.RadioButton_individual.Name = "RadioButton_individual"
        Me.RadioButton_individual.Size = New System.Drawing.Size(70, 17)
        Me.RadioButton_individual.TabIndex = 3
        Me.RadioButton_individual.Text = "Individual"
        Me.RadioButton_individual.UseVisualStyleBackColor = True
        '
        'RadioButton_sofa
        '
        Me.RadioButton_sofa.AutoSize = True
        Me.RadioButton_sofa.Location = New System.Drawing.Point(17, 28)
        Me.RadioButton_sofa.Name = "RadioButton_sofa"
        Me.RadioButton_sofa.Size = New System.Drawing.Size(47, 17)
        Me.RadioButton_sofa.TabIndex = 2
        Me.RadioButton_sofa.Text = "Sofa"
        Me.RadioButton_sofa.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton_cuerina)
        Me.GroupBox2.Controls.Add(Me.RadioButton_cuero)
        Me.GroupBox2.Location = New System.Drawing.Point(180, 41)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(152, 104)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Tipo de Tela"
        '
        'RadioButton_cuerina
        '
        Me.RadioButton_cuerina.AutoSize = True
        Me.RadioButton_cuerina.Location = New System.Drawing.Point(17, 51)
        Me.RadioButton_cuerina.Name = "RadioButton_cuerina"
        Me.RadioButton_cuerina.Size = New System.Drawing.Size(61, 17)
        Me.RadioButton_cuerina.TabIndex = 3
        Me.RadioButton_cuerina.Text = "Cuerina"
        Me.RadioButton_cuerina.UseVisualStyleBackColor = True
        '
        'RadioButton_cuero
        '
        Me.RadioButton_cuero.AutoSize = True
        Me.RadioButton_cuero.Location = New System.Drawing.Point(17, 28)
        Me.RadioButton_cuero.Name = "RadioButton_cuero"
        Me.RadioButton_cuero.Size = New System.Drawing.Size(53, 17)
        Me.RadioButton_cuero.TabIndex = 2
        Me.RadioButton_cuero.Text = "Cuero"
        Me.RadioButton_cuero.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.column_venta, Me.column_tipo_sillon, Me.column_tipo_tela, Me.column_precio_costo, Me.column_precio_venta})
        Me.DataGridView1.Location = New System.Drawing.Point(14, 160)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(545, 222)
        Me.DataGridView1.TabIndex = 6
        '
        'column_venta
        '
        Me.column_venta.HeaderText = "ID_VENTA"
        Me.column_venta.Name = "column_venta"
        '
        'column_tipo_sillon
        '
        Me.column_tipo_sillon.HeaderText = "TIPO_SILLON"
        Me.column_tipo_sillon.Name = "column_tipo_sillon"
        '
        'column_tipo_tela
        '
        Me.column_tipo_tela.HeaderText = "TIPO_TELA"
        Me.column_tipo_tela.Name = "column_tipo_tela"
        '
        'column_precio_costo
        '
        Me.column_precio_costo.HeaderText = "PRECIO_COSTO"
        Me.column_precio_costo.Name = "column_precio_costo"
        '
        'column_precio_venta
        '
        Me.column_precio_venta.HeaderText = "PRECIO_VENTA"
        Me.column_precio_venta.Name = "column_precio_venta"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(351, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Precio Costo (Q):"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(350, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Precio Venta (Q):"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(351, 41)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Numero Venta:"
        '
        'TextBox_numero_venta
        '
        Me.TextBox_numero_venta.Location = New System.Drawing.Point(436, 37)
        Me.TextBox_numero_venta.Name = "TextBox_numero_venta"
        Me.TextBox_numero_venta.Size = New System.Drawing.Size(123, 20)
        Me.TextBox_numero_venta.TabIndex = 10
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(571, 395)
        Me.Controls.Add(Me.TextBox_numero_venta)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "201700620_Sillones"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents GuardaCalcularToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LimpiarGridToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LimpiarVectoresToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButton_doble As RadioButton
    Friend WithEvents RadioButton_individual As RadioButton
    Friend WithEvents RadioButton_sofa As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents RadioButton_cuerina As RadioButton
    Friend WithEvents RadioButton_cuero As RadioButton
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents column_venta As DataGridViewTextBoxColumn
    Friend WithEvents column_tipo_sillon As DataGridViewTextBoxColumn
    Friend WithEvents column_tipo_tela As DataGridViewTextBoxColumn
    Friend WithEvents column_precio_costo As DataGridViewTextBoxColumn
    Friend WithEvents column_precio_venta As DataGridViewTextBoxColumn
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox_numero_venta As TextBox
End Class
