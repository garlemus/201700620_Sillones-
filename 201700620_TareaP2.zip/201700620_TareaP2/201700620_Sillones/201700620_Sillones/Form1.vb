﻿Public Class Form1

    Dim contador_ventas As Integer
    Dim ventas(7, 4) As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        contador_ventas = 0
    End Sub

    Private Sub GuardaCalcularToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GuardaCalcularToolStripMenuItem.Click

        If contador_ventas > 7 Then
            MsgBox("¡ERROR! Ha sobrepasado el limite de ventas, limpie los vectores e intentelo de nuevo.")
            Return
        End If

        Dim numero_venta As String = TextBox_numero_venta.Text
        Dim tipo_sillon As String = "-"
        Dim tipo_tela As String = "-"
        Dim costo_tipo_sillon As Double = 0.0
        Dim costo_tipo_tela As Double = 0.0
        Dim cantidad_yardas As Double = 0.0

        If numero_venta = String.Empty Then
            MsgBox("¡ERROR! Se debe de indicar el número de venta.")
            Return
        End If

        If RadioButton_sofa.Checked Then
            tipo_sillon = "Sofa"
            costo_tipo_sillon = 250.99
            cantidad_yardas = 8.0
        ElseIf RadioButton_individual.Checked Then
            tipo_sillon = "Individual"
            costo_tipo_sillon = 150.99
            cantidad_yardas = 3.5
        ElseIf RadioButton_doble.Checked Then
            tipo_sillon = "Doble"
            costo_tipo_sillon = 200.99
            cantidad_yardas = 6.0
        Else
            MsgBox("¡ERROR! Se debe de seleccionar el tipo de sillón.")
            Return
        End If

        If RadioButton_cuero.Checked Then
            tipo_tela = "Cuero"
            costo_tipo_tela = 75.0
        ElseIf RadioButton_cuerina.Checked Then
            tipo_tela = "Cuerina"
            costo_tipo_tela = 45.99
        Else
            MsgBox("¡ERROR! Se debe de seleccionar el tipo de tela.")
            Return
        End If

        Dim precio_costo As Double = Math.Round(costo_tipo_sillon + cantidad_yardas * costo_tipo_tela, 2)
        Dim precio_venta As Double = Math.Round(precio_costo + precio_costo * 0.65, 2)
        'Dim precio_venta As Double = precio_costo / 0.35
        Label1.Text = "Precio Costo (Q): " + precio_costo.ToString()
        Label2.Text = "Precio Venta (Q): " + precio_venta.ToString()

        Dim venta As String() = {TextBox_numero_venta.Text, tipo_sillon, tipo_tela, precio_costo.ToString(), precio_venta.ToString()}

        DataGridView1.Rows.Add(venta)
        ventas(contador_ventas, 0) = venta(0)
        ventas(contador_ventas, 1) = venta(1)
        ventas(contador_ventas, 2) = venta(2)
        ventas(contador_ventas, 3) = venta(3)
        ventas(contador_ventas, 4) = venta(4)

        contador_ventas = contador_ventas + 1
    End Sub

    Private Sub LimpiarGridToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarGridToolStripMenuItem.Click
        DataGridView1.Rows.Clear()
        If contador_ventas > 0 Then
            For i As Integer = 0 To contador_ventas - 1
                Dim venta As String() = {ventas(i, 0), ventas(i, 1), ventas(i, 2), ventas(i, 3), ventas(i, 4)}
                DataGridView1.Rows.Add(venta)
            Next
        End If
        MsgBox("Grid limpiado correctamente.")
    End Sub

    Private Sub LimpiarVectoresToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LimpiarVectoresToolStripMenuItem.Click
        contador_ventas = 0
        MsgBox("Vectores limpiados correctamente.")
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Dim result = MsgBox("¿Estás seguro de querer salir?", vbYesNo)
        If result = vbYes Then
            Application.Exit()
        End If
    End Sub
End Class
